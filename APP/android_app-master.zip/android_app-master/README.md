# android_app
apk activity劫持 drozer
![](https://cdn.jsdelivr.net/gh/yanghaoi/android_app@latest/Image.png)
