package com.ofsoft.cms.admin.service.system;

import org.springframework.stereotype.Service;

/**
 * 缓存处理
 * 
 * @author OF
 * @date 2018年1月25日
 */
@Service
public class CacheService {
	public String system = "system";

}
