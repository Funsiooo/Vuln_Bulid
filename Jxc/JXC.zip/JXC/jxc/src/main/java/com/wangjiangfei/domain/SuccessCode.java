package com.wangjiangfei.domain;

/**
 * @author wangjiangfei
 * @date 2019/5/29 9:33
 * @description 成功码
 */
public interface SuccessCode {

    int SUCCESS_CODE = 100;
    String SUCCESS_MESS = "请求成功";

}
