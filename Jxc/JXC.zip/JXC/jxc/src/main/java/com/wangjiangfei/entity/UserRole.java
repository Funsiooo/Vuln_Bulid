package com.wangjiangfei.entity;

import lombok.Data;

@Data
public class UserRole {

  private Integer userRoleId;
  private Integer roleId;
  private Integer userId;

}
