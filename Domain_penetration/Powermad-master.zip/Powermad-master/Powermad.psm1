<#
.SYNOPSIS
Powermad - PowerShell MachineAccountQuota and DNS exploit tools
.LINK
https://github.com/Kevin-Robertson/Powermad
#>
Import-Module $PWD\Powermad.ps1
Import-Module $PWD\Invoke-DNSUpdate.ps1